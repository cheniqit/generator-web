package com.y;

import java.math.BigDecimal;
import java.util.Date;

public class billLoan {
    private Integer id;

    private BigDecimal money;

    private Integer periods;

    private Boolean loanType;

    private Integer loanLandlordId;

    private Integer rate;

    private Date loanDay;

    private Integer flatsId;

    private Integer auditorId;

    private Date auditTime;

    private Boolean audit;

    private Date createTime;

    private Boolean status;

    private String remark;

    private Date collectionDay;

    private Boolean isPayLoan;

    private String guarantee;

    private String guaranteePhone;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Integer getPeriods() {
        return periods;
    }

    public void setPeriods(Integer periods) {
        this.periods = periods;
    }

    public Boolean getLoanType() {
        return loanType;
    }

    public void setLoanType(Boolean loanType) {
        this.loanType = loanType;
    }

    public Integer getLoanLandlordId() {
        return loanLandlordId;
    }

    public void setLoanLandlordId(Integer loanLandlordId) {
        this.loanLandlordId = loanLandlordId;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public Date getLoanDay() {
        return loanDay;
    }

    public void setLoanDay(Date loanDay) {
        this.loanDay = loanDay;
    }

    public Integer getFlatsId() {
        return flatsId;
    }

    public void setFlatsId(Integer flatsId) {
        this.flatsId = flatsId;
    }

    public Integer getAuditorId() {
        return auditorId;
    }

    public void setAuditorId(Integer auditorId) {
        this.auditorId = auditorId;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public Boolean getAudit() {
        return audit;
    }

    public void setAudit(Boolean audit) {
        this.audit = audit;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Date getCollectionDay() {
        return collectionDay;
    }

    public void setCollectionDay(Date collectionDay) {
        this.collectionDay = collectionDay;
    }

    public Boolean getIsPayLoan() {
        return isPayLoan;
    }

    public void setIsPayLoan(Boolean isPayLoan) {
        this.isPayLoan = isPayLoan;
    }

    public String getGuarantee() {
        return guarantee;
    }

    public void setGuarantee(String guarantee) {
        this.guarantee = guarantee == null ? null : guarantee.trim();
    }

    public String getGuaranteePhone() {
        return guaranteePhone;
    }

    public void setGuaranteePhone(String guaranteePhone) {
        this.guaranteePhone = guaranteePhone == null ? null : guaranteePhone.trim();
    }
}