package com.y;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class billLoanExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public billLoanExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andMoneyIsNull() {
            addCriterion("money is null");
            return (Criteria) this;
        }

        public Criteria andMoneyIsNotNull() {
            addCriterion("money is not null");
            return (Criteria) this;
        }

        public Criteria andMoneyEqualTo(BigDecimal value) {
            addCriterion("money =", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyNotEqualTo(BigDecimal value) {
            addCriterion("money <>", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyGreaterThan(BigDecimal value) {
            addCriterion("money >", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("money >=", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyLessThan(BigDecimal value) {
            addCriterion("money <", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("money <=", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyIn(List<BigDecimal> values) {
            addCriterion("money in", values, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyNotIn(List<BigDecimal> values) {
            addCriterion("money not in", values, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("money between", value1, value2, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("money not between", value1, value2, "money");
            return (Criteria) this;
        }

        public Criteria andPeriodsIsNull() {
            addCriterion("periods is null");
            return (Criteria) this;
        }

        public Criteria andPeriodsIsNotNull() {
            addCriterion("periods is not null");
            return (Criteria) this;
        }

        public Criteria andPeriodsEqualTo(Integer value) {
            addCriterion("periods =", value, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsNotEqualTo(Integer value) {
            addCriterion("periods <>", value, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsGreaterThan(Integer value) {
            addCriterion("periods >", value, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsGreaterThanOrEqualTo(Integer value) {
            addCriterion("periods >=", value, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsLessThan(Integer value) {
            addCriterion("periods <", value, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsLessThanOrEqualTo(Integer value) {
            addCriterion("periods <=", value, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsIn(List<Integer> values) {
            addCriterion("periods in", values, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsNotIn(List<Integer> values) {
            addCriterion("periods not in", values, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsBetween(Integer value1, Integer value2) {
            addCriterion("periods between", value1, value2, "periods");
            return (Criteria) this;
        }

        public Criteria andPeriodsNotBetween(Integer value1, Integer value2) {
            addCriterion("periods not between", value1, value2, "periods");
            return (Criteria) this;
        }

        public Criteria andLoanTypeIsNull() {
            addCriterion("loanType is null");
            return (Criteria) this;
        }

        public Criteria andLoanTypeIsNotNull() {
            addCriterion("loanType is not null");
            return (Criteria) this;
        }

        public Criteria andLoanTypeEqualTo(Boolean value) {
            addCriterion("loanType =", value, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeNotEqualTo(Boolean value) {
            addCriterion("loanType <>", value, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeGreaterThan(Boolean value) {
            addCriterion("loanType >", value, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeGreaterThanOrEqualTo(Boolean value) {
            addCriterion("loanType >=", value, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeLessThan(Boolean value) {
            addCriterion("loanType <", value, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeLessThanOrEqualTo(Boolean value) {
            addCriterion("loanType <=", value, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeIn(List<Boolean> values) {
            addCriterion("loanType in", values, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeNotIn(List<Boolean> values) {
            addCriterion("loanType not in", values, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeBetween(Boolean value1, Boolean value2) {
            addCriterion("loanType between", value1, value2, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanTypeNotBetween(Boolean value1, Boolean value2) {
            addCriterion("loanType not between", value1, value2, "loanType");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdIsNull() {
            addCriterion("loanLandlordId is null");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdIsNotNull() {
            addCriterion("loanLandlordId is not null");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdEqualTo(Integer value) {
            addCriterion("loanLandlordId =", value, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdNotEqualTo(Integer value) {
            addCriterion("loanLandlordId <>", value, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdGreaterThan(Integer value) {
            addCriterion("loanLandlordId >", value, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("loanLandlordId >=", value, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdLessThan(Integer value) {
            addCriterion("loanLandlordId <", value, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdLessThanOrEqualTo(Integer value) {
            addCriterion("loanLandlordId <=", value, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdIn(List<Integer> values) {
            addCriterion("loanLandlordId in", values, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdNotIn(List<Integer> values) {
            addCriterion("loanLandlordId not in", values, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdBetween(Integer value1, Integer value2) {
            addCriterion("loanLandlordId between", value1, value2, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andLoanLandlordIdNotBetween(Integer value1, Integer value2) {
            addCriterion("loanLandlordId not between", value1, value2, "loanLandlordId");
            return (Criteria) this;
        }

        public Criteria andRateIsNull() {
            addCriterion("rate is null");
            return (Criteria) this;
        }

        public Criteria andRateIsNotNull() {
            addCriterion("rate is not null");
            return (Criteria) this;
        }

        public Criteria andRateEqualTo(Integer value) {
            addCriterion("rate =", value, "rate");
            return (Criteria) this;
        }

        public Criteria andRateNotEqualTo(Integer value) {
            addCriterion("rate <>", value, "rate");
            return (Criteria) this;
        }

        public Criteria andRateGreaterThan(Integer value) {
            addCriterion("rate >", value, "rate");
            return (Criteria) this;
        }

        public Criteria andRateGreaterThanOrEqualTo(Integer value) {
            addCriterion("rate >=", value, "rate");
            return (Criteria) this;
        }

        public Criteria andRateLessThan(Integer value) {
            addCriterion("rate <", value, "rate");
            return (Criteria) this;
        }

        public Criteria andRateLessThanOrEqualTo(Integer value) {
            addCriterion("rate <=", value, "rate");
            return (Criteria) this;
        }

        public Criteria andRateIn(List<Integer> values) {
            addCriterion("rate in", values, "rate");
            return (Criteria) this;
        }

        public Criteria andRateNotIn(List<Integer> values) {
            addCriterion("rate not in", values, "rate");
            return (Criteria) this;
        }

        public Criteria andRateBetween(Integer value1, Integer value2) {
            addCriterion("rate between", value1, value2, "rate");
            return (Criteria) this;
        }

        public Criteria andRateNotBetween(Integer value1, Integer value2) {
            addCriterion("rate not between", value1, value2, "rate");
            return (Criteria) this;
        }

        public Criteria andLoanDayIsNull() {
            addCriterion("loanDay is null");
            return (Criteria) this;
        }

        public Criteria andLoanDayIsNotNull() {
            addCriterion("loanDay is not null");
            return (Criteria) this;
        }

        public Criteria andLoanDayEqualTo(Date value) {
            addCriterion("loanDay =", value, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayNotEqualTo(Date value) {
            addCriterion("loanDay <>", value, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayGreaterThan(Date value) {
            addCriterion("loanDay >", value, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayGreaterThanOrEqualTo(Date value) {
            addCriterion("loanDay >=", value, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayLessThan(Date value) {
            addCriterion("loanDay <", value, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayLessThanOrEqualTo(Date value) {
            addCriterion("loanDay <=", value, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayIn(List<Date> values) {
            addCriterion("loanDay in", values, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayNotIn(List<Date> values) {
            addCriterion("loanDay not in", values, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayBetween(Date value1, Date value2) {
            addCriterion("loanDay between", value1, value2, "loanDay");
            return (Criteria) this;
        }

        public Criteria andLoanDayNotBetween(Date value1, Date value2) {
            addCriterion("loanDay not between", value1, value2, "loanDay");
            return (Criteria) this;
        }

        public Criteria andFlatsIdIsNull() {
            addCriterion("flatsId is null");
            return (Criteria) this;
        }

        public Criteria andFlatsIdIsNotNull() {
            addCriterion("flatsId is not null");
            return (Criteria) this;
        }

        public Criteria andFlatsIdEqualTo(Integer value) {
            addCriterion("flatsId =", value, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdNotEqualTo(Integer value) {
            addCriterion("flatsId <>", value, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdGreaterThan(Integer value) {
            addCriterion("flatsId >", value, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("flatsId >=", value, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdLessThan(Integer value) {
            addCriterion("flatsId <", value, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdLessThanOrEqualTo(Integer value) {
            addCriterion("flatsId <=", value, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdIn(List<Integer> values) {
            addCriterion("flatsId in", values, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdNotIn(List<Integer> values) {
            addCriterion("flatsId not in", values, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdBetween(Integer value1, Integer value2) {
            addCriterion("flatsId between", value1, value2, "flatsId");
            return (Criteria) this;
        }

        public Criteria andFlatsIdNotBetween(Integer value1, Integer value2) {
            addCriterion("flatsId not between", value1, value2, "flatsId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdIsNull() {
            addCriterion("auditorId is null");
            return (Criteria) this;
        }

        public Criteria andAuditorIdIsNotNull() {
            addCriterion("auditorId is not null");
            return (Criteria) this;
        }

        public Criteria andAuditorIdEqualTo(Integer value) {
            addCriterion("auditorId =", value, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdNotEqualTo(Integer value) {
            addCriterion("auditorId <>", value, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdGreaterThan(Integer value) {
            addCriterion("auditorId >", value, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("auditorId >=", value, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdLessThan(Integer value) {
            addCriterion("auditorId <", value, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdLessThanOrEqualTo(Integer value) {
            addCriterion("auditorId <=", value, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdIn(List<Integer> values) {
            addCriterion("auditorId in", values, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdNotIn(List<Integer> values) {
            addCriterion("auditorId not in", values, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdBetween(Integer value1, Integer value2) {
            addCriterion("auditorId between", value1, value2, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditorIdNotBetween(Integer value1, Integer value2) {
            addCriterion("auditorId not between", value1, value2, "auditorId");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIsNull() {
            addCriterion("auditTime is null");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIsNotNull() {
            addCriterion("auditTime is not null");
            return (Criteria) this;
        }

        public Criteria andAuditTimeEqualTo(Date value) {
            addCriterion("auditTime =", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotEqualTo(Date value) {
            addCriterion("auditTime <>", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeGreaterThan(Date value) {
            addCriterion("auditTime >", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("auditTime >=", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeLessThan(Date value) {
            addCriterion("auditTime <", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeLessThanOrEqualTo(Date value) {
            addCriterion("auditTime <=", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIn(List<Date> values) {
            addCriterion("auditTime in", values, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotIn(List<Date> values) {
            addCriterion("auditTime not in", values, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeBetween(Date value1, Date value2) {
            addCriterion("auditTime between", value1, value2, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotBetween(Date value1, Date value2) {
            addCriterion("auditTime not between", value1, value2, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditIsNull() {
            addCriterion("audit is null");
            return (Criteria) this;
        }

        public Criteria andAuditIsNotNull() {
            addCriterion("audit is not null");
            return (Criteria) this;
        }

        public Criteria andAuditEqualTo(Boolean value) {
            addCriterion("audit =", value, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditNotEqualTo(Boolean value) {
            addCriterion("audit <>", value, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditGreaterThan(Boolean value) {
            addCriterion("audit >", value, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditGreaterThanOrEqualTo(Boolean value) {
            addCriterion("audit >=", value, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditLessThan(Boolean value) {
            addCriterion("audit <", value, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditLessThanOrEqualTo(Boolean value) {
            addCriterion("audit <=", value, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditIn(List<Boolean> values) {
            addCriterion("audit in", values, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditNotIn(List<Boolean> values) {
            addCriterion("audit not in", values, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditBetween(Boolean value1, Boolean value2) {
            addCriterion("audit between", value1, value2, "audit");
            return (Criteria) this;
        }

        public Criteria andAuditNotBetween(Boolean value1, Boolean value2) {
            addCriterion("audit not between", value1, value2, "audit");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("createTime is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("createTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("createTime =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("createTime <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("createTime >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createTime >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("createTime <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("createTime <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("createTime in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("createTime not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("createTime between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("createTime not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Boolean value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Boolean value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Boolean value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Boolean value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Boolean value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Boolean value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Boolean> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Boolean> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Boolean value1, Boolean value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Boolean value1, Boolean value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCollectionDayIsNull() {
            addCriterion("collectionDay is null");
            return (Criteria) this;
        }

        public Criteria andCollectionDayIsNotNull() {
            addCriterion("collectionDay is not null");
            return (Criteria) this;
        }

        public Criteria andCollectionDayEqualTo(Date value) {
            addCriterion("collectionDay =", value, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayNotEqualTo(Date value) {
            addCriterion("collectionDay <>", value, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayGreaterThan(Date value) {
            addCriterion("collectionDay >", value, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayGreaterThanOrEqualTo(Date value) {
            addCriterion("collectionDay >=", value, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayLessThan(Date value) {
            addCriterion("collectionDay <", value, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayLessThanOrEqualTo(Date value) {
            addCriterion("collectionDay <=", value, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayIn(List<Date> values) {
            addCriterion("collectionDay in", values, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayNotIn(List<Date> values) {
            addCriterion("collectionDay not in", values, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayBetween(Date value1, Date value2) {
            addCriterion("collectionDay between", value1, value2, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andCollectionDayNotBetween(Date value1, Date value2) {
            addCriterion("collectionDay not between", value1, value2, "collectionDay");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanIsNull() {
            addCriterion("isPayLoan is null");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanIsNotNull() {
            addCriterion("isPayLoan is not null");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanEqualTo(Boolean value) {
            addCriterion("isPayLoan =", value, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanNotEqualTo(Boolean value) {
            addCriterion("isPayLoan <>", value, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanGreaterThan(Boolean value) {
            addCriterion("isPayLoan >", value, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanGreaterThanOrEqualTo(Boolean value) {
            addCriterion("isPayLoan >=", value, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanLessThan(Boolean value) {
            addCriterion("isPayLoan <", value, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanLessThanOrEqualTo(Boolean value) {
            addCriterion("isPayLoan <=", value, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanIn(List<Boolean> values) {
            addCriterion("isPayLoan in", values, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanNotIn(List<Boolean> values) {
            addCriterion("isPayLoan not in", values, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanBetween(Boolean value1, Boolean value2) {
            addCriterion("isPayLoan between", value1, value2, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andIsPayLoanNotBetween(Boolean value1, Boolean value2) {
            addCriterion("isPayLoan not between", value1, value2, "isPayLoan");
            return (Criteria) this;
        }

        public Criteria andGuaranteeIsNull() {
            addCriterion("guarantee is null");
            return (Criteria) this;
        }

        public Criteria andGuaranteeIsNotNull() {
            addCriterion("guarantee is not null");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEqualTo(String value) {
            addCriterion("guarantee =", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeNotEqualTo(String value) {
            addCriterion("guarantee <>", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeGreaterThan(String value) {
            addCriterion("guarantee >", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeGreaterThanOrEqualTo(String value) {
            addCriterion("guarantee >=", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeLessThan(String value) {
            addCriterion("guarantee <", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeLessThanOrEqualTo(String value) {
            addCriterion("guarantee <=", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeLike(String value) {
            addCriterion("guarantee like", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeNotLike(String value) {
            addCriterion("guarantee not like", value, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeIn(List<String> values) {
            addCriterion("guarantee in", values, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeNotIn(List<String> values) {
            addCriterion("guarantee not in", values, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeBetween(String value1, String value2) {
            addCriterion("guarantee between", value1, value2, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteeNotBetween(String value1, String value2) {
            addCriterion("guarantee not between", value1, value2, "guarantee");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneIsNull() {
            addCriterion("guaranteePhone is null");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneIsNotNull() {
            addCriterion("guaranteePhone is not null");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneEqualTo(String value) {
            addCriterion("guaranteePhone =", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneNotEqualTo(String value) {
            addCriterion("guaranteePhone <>", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneGreaterThan(String value) {
            addCriterion("guaranteePhone >", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneGreaterThanOrEqualTo(String value) {
            addCriterion("guaranteePhone >=", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneLessThan(String value) {
            addCriterion("guaranteePhone <", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneLessThanOrEqualTo(String value) {
            addCriterion("guaranteePhone <=", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneLike(String value) {
            addCriterion("guaranteePhone like", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneNotLike(String value) {
            addCriterion("guaranteePhone not like", value, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneIn(List<String> values) {
            addCriterion("guaranteePhone in", values, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneNotIn(List<String> values) {
            addCriterion("guaranteePhone not in", values, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneBetween(String value1, String value2) {
            addCriterion("guaranteePhone between", value1, value2, "guaranteePhone");
            return (Criteria) this;
        }

        public Criteria andGuaranteePhoneNotBetween(String value1, String value2) {
            addCriterion("guaranteePhone not between", value1, value2, "guaranteePhone");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}