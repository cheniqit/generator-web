package com.y;

import com.y.billLoan;
import com.y.billLoanExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface billLoanMapper {
    int countByExample(billLoanExample example);

    int deleteByExample(billLoanExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(billLoan record);

    int insertSelective(billLoan record);

    List<billLoan> selectByExample(billLoanExample example);

    billLoan selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") billLoan record, @Param("example") billLoanExample example);

    int updateByExample(@Param("record") billLoan record, @Param("example") billLoanExample example);

    int updateByPrimaryKeySelective(billLoan record);

    int updateByPrimaryKey(billLoan record);
}